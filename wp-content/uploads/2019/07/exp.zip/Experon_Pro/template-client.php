<?php
/**
 * Template Name: Clients
 *
 * @package ThinkUpThemes
 */

?>

	<?php get_template_part( 'archive', 'client' ); ?>