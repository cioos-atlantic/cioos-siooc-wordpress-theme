<div class="one_fifth last"><?php if(isset($content)){ echo $content;} ?></div>
<div class="clearboth"></div>