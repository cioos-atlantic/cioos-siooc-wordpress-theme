<?php
/**
*
* fieldgroups for thinkupshortcodes/carousel_team
*
* @package Thinkupshortcodes
* @author Think Up Themes Ltd contact@thinkupthemes.com
* @license GPL-2.0+
* @link www.thinkupthemes.com
* @copyright 2018 Think Up Themes Ltd
*/


$configfiles = array(
	self::get_path( __FILE__ ) . 'carousel_team-general.php', 
);

