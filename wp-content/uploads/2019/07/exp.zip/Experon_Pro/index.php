<?php
/**
 * The main template file.
 *
 * @package ThinkUpThemes
 */

	include( get_archive_template() );

?>