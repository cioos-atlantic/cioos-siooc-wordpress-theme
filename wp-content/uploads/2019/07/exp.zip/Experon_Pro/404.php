<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package ThinkUpThemes
 */

get_header(); ?>

			<?php thinkup_input_404content(); ?>

<?php get_footer(); ?>