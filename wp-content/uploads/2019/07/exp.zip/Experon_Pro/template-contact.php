<?php
/**
 * Template Name: Contact
 *
 * @package ThinkUpThemes
 */

get_header(); ?>

				<?php thinkup_input_contact(); ?>

				<?php get_template_part( 'page' ); ?>

<?php get_footer(); ?>