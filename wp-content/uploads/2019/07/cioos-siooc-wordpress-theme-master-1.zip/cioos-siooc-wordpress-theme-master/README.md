# cioos-siooc-wordpress-theme
Wordpress theme for the CIOOS-SIOOC website

Dependencie(s)
------------------
- Experon PRO theme

Installation
------------
Same installation process as any plugin on WordPress. You need to go in **Appearance** -> **Themes** -> **Add New** -> **Upload Theme** and upload the .zip file. After that, activate it.

Alternatively the contents of the archive can be placed directly in the wp-content/themes folder on your webhost.

### **Warning**
You may encounter some interface bugs at the menu level and the suddenly non-existing pre-header for example. We are still investigating on why it's happening but there's an easy way to get around this. You need to go in **Appearance** -> **Menus** -> **Manage Locations** and put back the right menus with the right locations.