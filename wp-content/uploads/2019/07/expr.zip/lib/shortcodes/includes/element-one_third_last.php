<div class="one_third last"><?php if(isset($content)){ echo $content;} ?></div>
<div class="clearboth"></div>