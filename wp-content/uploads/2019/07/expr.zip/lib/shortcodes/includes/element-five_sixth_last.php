<div class="five_sixth last"><?php if(isset($content)){ echo $content;} ?></div>
<div class="clearboth"></div>