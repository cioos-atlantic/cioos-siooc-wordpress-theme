<div class="one_half last"><?php if(isset($content)){ echo $content;} ?></div>
<div class="clearboth"></div>